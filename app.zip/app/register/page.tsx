'use client'

import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage,
} from '@/components/ui/form'

import { Button } from '@/src/components/ui/button'
import {
	Card,
	CardBody,
	CardDescription,
	CardFooter,
	CardHeader,
	CardTitle,
	createListCollection,
	HStack,
	Input,
	Portal,
	Select,
	Text,
} from '@chakra-ui/react'
import { zodResolver } from '@hookform/resolvers/zod'
import Cookies from 'js-cookie'
import { ArrowLeft } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { z } from 'zod'

const formSchema = z.object({
	username: z
		.string({
			message: 'Укажите почту',
		})
		.email({
			message: 'Укажите валидную почту',
		}),
	password: z.string().min(6, {
		message: 'Укажите пароль длиною не менее 6 символов',
	}),
	university: z
		.string({
			message: 'Укажите ВУЗ',
		})
		.array(),
})

const вузы = createListCollection({
	items: [
		{ label: 'Высшая Школа Экономики', value: 'hse' },
		{ label: 'МФТИ', value: 'mfti' },
		{ label: 'Центральный Университет', value: 'cu' },
		{ label: 'МИФИ', value: 'mifi' },
		{ label: 'МАИ', value: 'mai' },
	],
})

export default function AuthForm() {
	const { push, back } = useRouter()

	const form = useForm<z.infer<typeof formSchema>>({
		resolver: zodResolver(formSchema),
		defaultValues: {
			username: '',
			password: '',
		},
		mode: 'onChange',
	})

	async function onSubmit(data: z.infer<typeof formSchema>) {
		Cookies.set('token', '5747538945')
		push('/mentors')
		toast('Успешная регистрация')
		// await register(data)
		// 	.then(response => {
		// 		if (response.data.token) {
		// 			Cookies.set('token', response.data.token)
		// 			push('/mentors')
		// 			toast('Успешная регистрация')
		// 		}
		// 	})
		// 	.catch(err => {
		// 		if (err.status === 409) {
		// 			toast('Данный пользователь уже зарегистрирован')
		// 		}
		// 	})
	}

	return (
		<HStack justifyContent={'center'} mt={'16'} pb={'16'}>
			<div className='flex flex-col space-y-5'>
				<Card.Root
					bgColor={'black'}
					md={{
						w: '475px',
					}}
					lg={{
						w: '475px',
					}}
					w={'90vw'}
					// className='md:w-[475px] lg:w-[475px]'
					border={'none'}
				>
					<CardHeader>
						<button
							onClick={() => back()}
							className='mb-5 flex w-full cursor-pointer items-center gap-1 text-sm'
						>
							<ArrowLeft
								className='stroke-white'
								width={16}
								height={16}
								color='black'
							/>
							<Text color={'white'}>Назад</Text>
						</button>
						<CardDescription mb={'2'} className='text-sm text-gray-400'>
							СтудРеп
						</CardDescription>
						<CardTitle mb={'2'} color={'white'} className='mb-4 font-bold'>
							<p className='text-2xl'>Добро пожаловать!</p>
						</CardTitle>
						<CardDescription className='text-sm text-gray-400'>
							Зарегистрируйтесь на СтудРеп как учащийся
						</CardDescription>
					</CardHeader>
					<CardBody>
						<Form {...form}>
							<form onSubmit={form.handleSubmit(onSubmit)} id='login-form'>
								<div className='flex flex-col gap-4'>
									<div className='flex flex-col gap-2 space-y-1.5'>
										<FormField
											control={form.control}
											name='username'
											render={({ field }) => (
												<FormItem>
													<FormLabel>
														<Text color={'white'}>Почта</Text>
													</FormLabel>
													<FormControl>
														<Input
															borderColor={'#888888'}
															placeholder='Введите почту'
															color={'white'}
															{...field}
														/>
													</FormControl>
													<FormMessage />
												</FormItem>
											)}
										/>
									</div>
									<div className='flex flex-col gap-2 space-y-1.5'>
										<FormField
											control={form.control}
											name='password'
											render={({ field }) => (
												<FormItem>
													<Text color={'white'}>Пароль</Text>
													<FormControl>
														<Input
															borderColor={'#888888'}
															color={'white'}
															placeholder='Введите пароль'
															type='password'
															{...field}
														/>
													</FormControl>
													<FormMessage />
												</FormItem>
											)}
										/>
									</div>
									<div className='flex flex-col gap-2 space-y-1.5 mb-5'>
										<FormField
											control={form.control}
											name='university'
											render={({ field }) => (
												<FormItem>
													<Text color={'white'}>ВУЗ</Text>
													<FormControl>
														<Select.Root
															collection={вузы}
															name={field.name}
															value={field.value}
															onValueChange={({ value }) =>
																field.onChange(value)
															}
															onInteractOutside={() => field.onBlur()}
														>
															<Select.HiddenSelect color={'white'} />
															<Select.Control>
																<Select.Trigger
																	borderColor={'#888888'}
																	color={'white'}
																>
																	<Select.ValueText
																		_placeholder={{
																			color: 'white',
																		}}
																		placeholder='Выберите ВУЗ'
																	/>
																</Select.Trigger>
																<Select.IndicatorGroup color={'white'}>
																	<Select.Indicator color={'white'} />
																</Select.IndicatorGroup>
															</Select.Control>
															<Portal>
																<Select.Positioner>
																	<Select.Content bgColor={'black'}>
																		{вузы.items.map(framework => (
																			<Select.Item
																				item={framework}
																				key={framework.value}
																			>
																				{framework.label}
																				<Select.ItemIndicator />
																			</Select.Item>
																		))}
																	</Select.Content>
																</Select.Positioner>
															</Portal>
														</Select.Root>
													</FormControl>
													<FormMessage />
												</FormItem>
											)}
										/>
									</div>
								</div>
							</form>
						</Form>
					</CardBody>
					<CardFooter className='flex flex-col gap-2'>
						<Button
							bgColor={'#FFDE2C'}
							color={'black'}
							_hover={{
								bgColor: '#FFCD32',
							}}
							type='submit'
							form='login-form'
							className='w-full'
						>
							Зарегистрироваться
						</Button>
					</CardFooter>
				</Card.Root>
			</div>
		</HStack>
	)
}
