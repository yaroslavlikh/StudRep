import MentorsPage from '@/src/pages/MentorsPage'

export default function page() {
	return <MentorsPage />
}
