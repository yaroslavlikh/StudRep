import { Provider } from '@/src/components/ui/provider'
import Header from '@/src/layout/Header'
import type { Metadata } from 'next'
import './globals.css'

// const tbank = localFont({ src: './TinkoffSans-Medium.woff' })

export const metadata: Metadata = {
	title: 'CтудРеп',
	description: 'СтудРеп поможет Вам улучшить знания в определённой области.',
}

//${geistSans.variable} ${geistMono.variable}

export default function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode
}>) {
	return (
		<html lang='ru' suppressHydrationWarning>
			<body className={`antialiased`}>
				<Provider>
					<Header />
					{children}
				</Provider>
			</body>
		</html>
	)
}
