import { Box, Button, Container, HStack, Text, VStack } from '@chakra-ui/react'
import Link from 'next/link'

export default function Home() {
	return (
		<Box pb={'52'} className='pb-52'>
			<VStack as={'main'} mt={'32'} gap={'6'}>
				<Text color={'#C0C0C0'}>СтудРеп</Text>
				<VStack gap={'8'}>
					<Box as={'h1'} fontSize={'3xl'} textAlign={'center'} fontWeight={700}>
						Учиться - не стыдно. Стыдно не спрашивать помощи
					</Box>
					<Text color={'#C0C0C0'} textAlign={'center'}>
						Консультации, советы и наставничество от студентов твоего ВУЗа
					</Text>
				</VStack>
				<Link href={'/register'}>
					<Button
						bgColor={'#FFDE2C'}
						color={'black'}
						_hover={{
							bgColor: '#FFCD32',
						}}
						size={'2xl'}
						mt={'8'}
					>
						Начать учиться
					</Button>
				</Link>
			</VStack>
			<VStack mt={'32'}>
				<Text fontSize={'2xl'} mb={'12'} fontWeight={600}>
					Как это работает?
				</Text>
				<Container maxW={'7xl'}>
					<VStack w={'full'} gap={'20'}>
						<VStack alignSelf={'flex-start'}>
							<Text fontSize={'xl'} fontWeight={500}>
								Зарегистрируйся и выбери роль
							</Text>
							<Text color={'#C0C0C0'} maxW={'400px'}>
								Хочешь помощь — ищи репетитора. Хочешь заработать — создавай
								профиль и принимай учеников.
							</Text>
						</VStack>
						<VStack>
							<Text fontSize={'xl'} fontWeight={500}>
								Найди подходящего ученика или учителя
							</Text>
							<Text color={'#C0C0C0'} maxW={'400px'}>
								Поиск по вузу, предмету, типу задачи и рейтингу.
							</Text>
						</VStack>
						<VStack alignSelf={'flex-end'}>
							<Text fontSize={'xl'} fontWeight={500}>
								Получи знания или заработай
							</Text>
							<Text color={'#C0C0C0'} maxW={'400px'}>
								Созвон, чат, помощь с заданиями — всё просто. После выполнения —
								отзыв и рейтинг.
							</Text>
						</VStack>
					</VStack>
				</Container>
			</VStack>
			<HStack
				justifyContent={'center'}
				alignItems={'center'}
				gap={'8'}
				mt={'32'}
				flexFlow={'column'}
				md={{
					flexFlow: 'row',
				}}
			>
				<Link href={'/register'}>
					<Button
						bgColor={'#FFDE2C'}
						color={'black'}
						_hover={{
							bgColor: '#FFCD32',
						}}
						size={'2xl'}
					>
						Хочу учиться
					</Button>
				</Link>
				<Text>или</Text>
				<Button
					bgColor={'#FFDE2C'}
					color={'black'}
					_hover={{
						bgColor: '#FFCD32',
					}}
					size={'2xl'}
				>
					Хочу учить
				</Button>
			</HStack>
		</Box>
	)
}
