'use client'

import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage,
} from '@/components/ui/form'

import { api } from '@/src/api/api'
import { Button } from '@/src/components/ui/button'
import {
	Card,
	CardBody,
	CardDescription,
	CardFooter,
	CardHeader,
	CardTitle,
	HStack,
	Input,
	Text,
} from '@chakra-ui/react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation } from '@tanstack/react-query'
import Cookies from 'js-cookie'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { z } from 'zod'

const formSchema = z.object({
	username: z
		.string({
			message: 'Укажите почту',
		})
		.email({
			message: 'Укажите валидную почту',
		}),
	password: z.string().min(6, {
		message: 'Укажите пароль длиною не менее 6 символов',
	}),
})

export default function AuthForm() {
	const { push } = useRouter()

	const form = useForm<z.infer<typeof formSchema>>({
		resolver: zodResolver(formSchema),
		defaultValues: {
			username: '',
			password: '',
		},
		mode: 'onChange',
	})

	const { mutateAsync: login } = useMutation({
		mutationFn: async (data: z.infer<typeof formSchema>) =>
			await api.post('/auth/basic/login', {
				login: data.username,
				password: data.password,
			}),
	})

	function onSubmit(data: z.infer<typeof formSchema>) {
		Cookies.set('token', '3sfbeh723723')
		push('/mentors')
		toast('Успешный вход')
		// login(data)
		// 	.then(response => {
		// 		if (response.data.token) {
		// 			Cookies.set('token', response.data.token)
		// 			push('/mentors')
		// 			toast('Успешный вход')
		// 		}
		// 	})
		// 	.catch(err => {
		// 		if (err.status === 404) {
		// 			toast('Данный пользователь не найден')
		// 		}
		// 	})
	}

	return (
		<HStack justifyContent={'center'} mt={'16'} pb={'16'}>
			<div className='flex flex-col space-y-5'>
				<Card.Root
					bgColor={'black'}
					md={{
						w: '475px',
					}}
					lg={{
						w: '475px',
					}}
					w={'90vw'}
					// className='md:w-[475px] lg:w-[475px]'
					border={'none'}
				>
					<CardHeader>
						<Link
							href='/'
							className='mb-5 flex w-full cursor-pointer items-center gap-1 text-sm'
						>
							<ArrowLeft
								className='stroke-white'
								width={16}
								height={16}
								color='black'
							/>
							<Text color={'white'}>Назад</Text>
						</Link>
						<CardDescription mb={'2'} className='text-sm text-gray-400'>
							СтудРеп
						</CardDescription>
						<CardTitle mb={'2'} color={'white'} className='mb-4 font-bold'>
							<p className='text-2xl'>Добро пожаловать!</p>
						</CardTitle>
						<CardDescription className='text-sm text-gray-400'>
							Выполните вход в свой аккаунт
						</CardDescription>
					</CardHeader>
					<CardBody>
						<Form {...form}>
							<form id='login-form' onSubmit={form.handleSubmit(onSubmit)}>
								<div className='flex flex-col gap-4'>
									<div className='flex flex-col gap-2 space-y-1.5'>
										<FormField
											control={form.control}
											name='username'
											render={({ field }) => (
												<FormItem>
													<FormLabel>
														<Text color={'white'}>Почта</Text>
													</FormLabel>
													<FormControl>
														<Input
															borderColor={'#888888'}
															placeholder='Введите почту'
															color={'white'}
															{...field}
														/>
													</FormControl>
													<FormMessage />
												</FormItem>
											)}
										/>
									</div>
									<div className='flex flex-col gap-2 space-y-1.5'>
										<FormField
											control={form.control}
											name='password'
											render={({ field }) => (
												<FormItem>
													<Text color={'white'}>Пароль</Text>
													<FormControl>
														<Input
															borderColor={'#888888'}
															color={'white'}
															placeholder='Введите пароль'
															type='password'
															{...field}
														/>
													</FormControl>
													<FormMessage />
												</FormItem>
											)}
										/>
									</div>
								</div>
							</form>
						</Form>
					</CardBody>
					<CardFooter className='flex flex-col gap-2'>
						<Button
							bgColor={'#FFDE2C'}
							color={'black'}
							_hover={{
								bgColor: '#FFCD32',
							}}
							type='submit'
							form='login-form'
							className='w-full'
						>
							Войти
						</Button>
						<Link href='/register' className='block w-full'>
							<Button variant='subtle' className='w-full'>
								<HStack>
									<Text>Зарегистрироваться</Text>
									<ArrowRight
										stroke='black'
										style={{
											width: 16,
											height: 16,
										}}
									/>
								</HStack>
							</Button>
						</Link>
					</CardFooter>
				</Card.Root>
			</div>
		</HStack>
	)
}
