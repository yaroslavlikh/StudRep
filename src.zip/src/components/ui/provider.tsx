'use client'

import { ChakraProvider, createSystem, defaultConfig } from '@chakra-ui/react'

import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactNode } from 'react'

export const queryClient = new QueryClient()

export const system = createSystem(defaultConfig, {
	disableLayers: true,
})

export function Provider({ children }: { children: ReactNode }) {
	return (
		<QueryClientProvider client={queryClient}>
			<ChakraProvider value={system}>{children}</ChakraProvider>
		</QueryClientProvider>
	)
}
