import { Container, Heading, HStack } from '@chakra-ui/react'
import Link from 'next/link'
import { Button } from '../components/ui/button'

export default function Header() {
	return (
		<div className='bg-black'>
			<Container maxW={'7xl'} py={'4'}>
				<HStack className='px-6' justifyContent={'space-between'}>
					<Link href={'/'}>
						<Heading as={'h3'} fontWeight={'semibold'}>
							СтудРеп
						</Heading>
					</Link>
					<HStack>
						<Link href={'/login'}>
							<Button bg={'transparent'} color={'#4972CF'}>
								Личный кабинет
							</Button>
						</Link>
						{/* <Button
							bgColor={'#FFDE2C'}
							color={'black'}
							_hover={{
								bgColor: '#FFCD32',
							}}
							// fontSize={'medium'}
						>
							Войти
						</Button> */}
					</HStack>
				</HStack>
			</Container>
		</div>
	)
}
