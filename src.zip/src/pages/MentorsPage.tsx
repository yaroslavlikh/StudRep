'use client'

import {
	Avatar,
	Box,
	Button,
	Card,
	CardBody,
	CloseButton,
	Container,
	Dialog,
	Grid,
	HStack,
	Input,
	Portal,
	Text,
	VStack,
} from '@chakra-ui/react'
import { AlignJustify } from 'lucide-react'
import { useState } from 'react'
import { Provider } from '../components/ui/provider'

interface Item {
	name: string
	spec: string
	rate: string
}

const items: Item[] = [
	{
		name: 'Эдуард Ждановский',
		spec: 'ML разработка',
		rate: '4.8',
	},
	{
		name: 'Ефим Александров',
		spec: 'Основы бизнеса',
		rate: '4.5',
	},
	{
		name: 'Илья Маликов',
		spec: 'Математика',
		rate: '4.9',
	},
	{
		name: 'Семен Березкин',
		spec: 'Экономика',
		rate: '4.7',
	},
	{
		name: 'Кирилл Баранов',
		spec: 'Python разработка',
		rate: '4.8',
	},
	{
		name: 'Пётр Поддубняк',
		spec: 'Астрономия',
		rate: '4.4',
	},
	{
		name: 'Никита Чехов',
		spec: 'Frontend разработка',
		rate: '5.0',
	},
	{
		name: 'Райан Гослинг',
		spec: 'Backend разработка',
		rate: '4.7',
	},
	{
		name: 'Павел Павленко',
		spec: 'Анализ данных',
		rate: '4.8',
	},
]

export default function MentorsPage() {
	const [searchTerm, setSearchTerm] = useState('')

	return (
		<Provider>
			<Box mt={'16'}>
				<Box
					as={'h1'}
					fontSize={'2xl'}
					textAlign={'center'}
					fontWeight={700}
					mb={'8'}
					md={{
						fontSize: '3xl',
					}}
				>
					Репетиторы на Ваш выбор
				</Box>
				<HStack
					md={{
						maxW: '600px',
					}}
					maxW={'325px'}
					mx={'auto'}
				>
					<Input
						value={searchTerm}
						onChange={e => setSearchTerm(e.target.value)}
						placeholder='Поиск...'
						borderColor={'#787878'}
					/>
					<Button p={0}>
						<AlignJustify width={12} height={12} />
					</Button>
				</HStack>
				<Container maxW={'7xl'} mt={'12'}>
					<Grid
						gap={'4'}
						md={{
							gridTemplateColumns: 'repeat(3, 1fr)',
						}}
						templateColumns={'1fr'}
						pb={'8'}
					>
						{items
							.filter(
								item =>
									item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
									item.spec.toLowerCase().includes(searchTerm.toLowerCase())
							)
							.map(item => (
								<Dialog.Root key={item.name}>
									<Dialog.Trigger asChild>
										<Card.Root
											bgColor={'black'}
											key={item.name}
											cursor={'pointer'}
											borderColor={'#212121'}
											transition={'colors'}
											_hover={{
												bgColor: '#302F2F',
											}}
										>
											<CardBody>
												<VStack alignItems={'flex-start'} gap={'4'}>
													<HStack gap={'4'}>
														<Avatar.Root size={'xl'}>
															<Avatar.Fallback name={item.name} />
														</Avatar.Root>
														<Text fontWeight={500} color={'white'}>
															{item.name}
														</Text>
													</HStack>
													<Text fontWeight={500} color={'#C0C0C0'}>
														{item.spec}
													</Text>
												</VStack>
											</CardBody>
										</Card.Root>
									</Dialog.Trigger>
									<Portal>
										<Dialog.Backdrop />
										<Dialog.Positioner>
											<Dialog.Content bgColor={'black'}>
												<Dialog.Header>
													<Dialog.Title>{item.name}</Dialog.Title>
												</Dialog.Header>
												<Dialog.Body>
													<Avatar.Root size={'2xl'} mb={'4'}>
														<Avatar.Fallback name={item.name} />
													</Avatar.Root>
													<p>Курс: 4 курс, ВШЭ</p>
													<p>
														Направление: Прикладная математика и информатика.
													</p>
													<p>
														Специализация: Машинное обучение, нейросети, Python
													</p>
													<Text mt={'4'}>
														Привет! Я — ML-разработчик с опытом участия в
														хакатонах и стажировок в крупных IT-компаниях.
														Помогаю разобраться в основах машинного обучения,
														обучаю работе с библиотеками scikit-learn, pandas,
														TensorFlow и PyTorch, а также объясняю, как устроены
														модели “под капотом”. Работаю как с новичками, так и
														с теми, кто хочет углубиться в модели и оптимизацию.
													</Text>
												</Dialog.Body>
												<Dialog.Footer justifyContent={'space-between'}>
													<Text fontWeight={500} fontSize={'xl'}>
														1000₽/час
													</Text>
													<Button>Связаться</Button>
												</Dialog.Footer>
												<Dialog.CloseTrigger asChild>
													<CloseButton
														_hover={{
															bgColor: '#18181B',
														}}
														size='sm'
														color={'white'}
													/>
												</Dialog.CloseTrigger>
											</Dialog.Content>
										</Dialog.Positioner>
									</Portal>
								</Dialog.Root>
							))}
					</Grid>
				</Container>
			</Box>
		</Provider>
	)
}
